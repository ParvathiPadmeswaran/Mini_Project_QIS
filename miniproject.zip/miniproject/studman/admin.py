from django.contrib import admin
from studman.models import *
# Register your models here.
#26/11/2025
admin.site.register(Student)
admin.site.register(Teacher)
admin.site.register(ContactMessage)
admin.site.register(LeaveApplication)
admin.site.register(Result)
admin.site.register(TeacherMessage)
admin.site.register(AdminMessage)